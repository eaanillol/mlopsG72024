#!bin/bash
 sudo microk8s kubectl describe secret -n kube-system microk8s-dashboard-token
